
Instructions:
Start by making a folder and extract the contents of Examples.zip
there. If you then double-click on the file 'Command Prompt', that
should open a little DOS window for you. This works in XP, anyway.
If you're using Vista you may have to go into DOS manually.

There are six example files, written in Tig source code. You 
compile these using the Tig compiler: TC. Just type 'TC <filename>'
and hit Return - 'TC example1.txt' for example. This will compile
the source code into a file of bytecode called example1.tig, 
example2.tig, etc. You can then execute it using the interpreter,
VMTest. That is: 'VMTest example1.tig'.

However, this won't be very edifying unless you've looked at the
source code first. Tig code is written in straight ascii, so just
open the files in Notepad or your wordprocessor or whatever.
You'll see that Tig is most like a simplified version of C++.

You'll also notice that when you compile a program, TC churns
out some arcane diagnostic text on screen. You can safely ignore 
this, but if you give it a glance you'll see that it's a 
transcript of the virtual machine code into which the program is
being compiled.